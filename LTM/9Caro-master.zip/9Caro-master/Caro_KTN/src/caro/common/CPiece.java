package caro.common;

import java.io.Serializable;

public class CPiece implements Serializable{

    public int State;
    static public final int EMPTY = 0;
    static public final int WHITE = 1;
    static public final int BLACK = 2;


}  