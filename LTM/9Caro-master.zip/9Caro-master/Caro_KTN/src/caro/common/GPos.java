package caro.common;

import java.io.Serializable;

public class GPos implements Serializable {
    public int x;
    public int y;
}  